from django.urls import path
from .views import main_page, AboutUs, thanks, contact_list, contact_update, contact_delete, contact_create, galeria, cadastrar

urlpatterns = [
    path('', main_page, name='main_page'),
    path('AboutUs/', AboutUs, name='AboutUs'),
    path('thanks/', thanks, name='thanks'),
    path('contact_list/', contact_list, name='contact_list'),
    path('update/<int:pk>', contact_update, name='contact_update'),
    path('delete/<int:pk>', contact_delete, name='contact_delete'),
    path('create/', contact_create, name='contact_create'),
    path('galeria/', galeria, name='galeria'),
    path('cadastrar/', cadastrar, name='cadastrar'),
]