from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from .forms import ContactForm
from .models import Contact

#Pagina principal
def main_page(requests):
    return render(requests, 'boxe/main.html')

#Pagina sobre nós
def AboutUs(requests):
    return render(requests, 'boxe/AboutUs.html')

#Pagina de agardecimento
def thanks(request):
    return render(request, 'boxe/thanks.html')

def galeria(request):
    return render(request, 'boxe/galeria.html')

def cadastrar(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('thanks')
    else:
        form = ContactForm()
    return render(request, 'boxe/cadastrar.html',
                  {'form': form})

#Lista de contatos
def contact_list(request):
    contacts = Contact.objects.all()
    return render(request, 'boxe/contact_list.html',
                  {'contacts': contacts})

#Pagina criar contatos
def contact_create(requests):
    if requests.method == 'POST':
        form = ContactForm(requests.POST)
        if form.is_valid():
            form.save()
            return redirect('contact_list')
    else:
        form = ContactForm
    return render(requests, 'boxe/contact_form.html', {'form' : form})
#Pagina atualizar contatos
def contact_update(requests, pk):
    contact = get_object_or_404(Contact, pk = pk)
    if requests.method == 'POST':
        form = ContactForm(requests.POST, instance=contact)
        if form.is_valid():
            form.save()
            return redirect('contact_list')
    else:
        form = ContactForm(instance=contact)
    return render(requests, 'boxe/contact_form.html', {'form' : form})

#Pagina deletar contatos
def contact_delete(requests, pk):
    contact = get_object_or_404(Contact, pk=pk)
    if requests.method == 'POST':
        contact.delete()
        return redirect('contact_list')
    return render(requests, 'boxe/contact_confirm_delete.html', {'contact' : contact})